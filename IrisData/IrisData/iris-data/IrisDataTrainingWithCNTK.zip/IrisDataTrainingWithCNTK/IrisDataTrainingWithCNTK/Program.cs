﻿using CNTK;
using CNTK.NET.Samples;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IrisDataTrainingWithCNTK
{
    class Program
    {
        static void Main(string[] args)
        {
            //13-Nov-2017 blog post: https://bhrnjica.net/2017/11/13/train-iris-data-with-minibatchsource-using-cntk-and-c/
            // CNTK_TrainIrisData.TrainIrisByMinibatchSource(DeviceDescriptor.CPUDevice);

            //14 -Nov-2017 blog post: https://bhrnjica.net/2017/11/14/train-iris-data-by-batch-using-cntk-and-c/
            // CNTK_TrainIrisData.TrainIriswithBatch(DeviceDescriptor.CPUDevice);

            //15-Nov-2017 blog post: https://bhrnjica.net/2017/11/15/testing-and-validation-cntk-models-using-c/
            CNTK_EvaluateIrisData.TrainIris(DeviceDescriptor.CPUDevice);
        }
    }
}
